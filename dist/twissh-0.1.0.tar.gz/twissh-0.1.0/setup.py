# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['twissh']

package_data = \
{'': ['*']}

install_requires = \
['Twisted>=22.4.0,<23.0.0',
 'esper>=2.1,<3.0',
 'pygame==2.1.3.dev8',
 'urwid>=2.1.2,<3.0.0']

setup_kwargs = {
    'name': 'twissh',
    'version': '0.1.0',
    'description': '',
    'long_description': "## Start server\n\n`./run.sh`\n\n## Connect\n\n`ssh localhost -p 6022`\n\n\n## Known bugs\n\nIf shift arrow does not work, be sure to have it properly escaped in you terminal settings\n\n\n# Math Class H\n\nManage your crew of mathematicians to the top of the world. Research new theorems, hire the best talent, and even compromise on using less orthodox methods if necessary...\n\nBut pay attention to your group mental wellness, otherwise thy could get too stressed and lose their minds.\nIn that case, legend says they are 'retired' to the pit...\n\nAntoher legend: some mathematicians are righteous among men, or Lamedvavnik. They are so righteous that they can't be fired, even if they are not doing anything. They are also immune to stress.\n\n# Hack'n'Slassh\n\nAlas, adventurer! Welcome to the pit...\n\nYou have been sent to the pit to prove your worth and become the village next hero. But beware, the pit is a dangerous place, and you will have to fight your way out.\nSome weird and crazy creatures are regularly sent to it, nobody know where they come from, but they keep talking about Langlands and some weird math stuff...\n\n\n\n# Gameplay\n\nStart playing math class H. When a mathematician gets crazy, they can sent to the pit. You can log in to hack'n'slash using the ID of the pitted mathematician and try to get out of the pit.\n\n- Login in using nothing: create new math class H game. \n- Login using research group ID: join existing math class H game. \n- Login using pitted mathematician ID: play hack'n'slash.",
    'author': 'Alessandro Ricottone',
    'author_email': 'ricott2@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
