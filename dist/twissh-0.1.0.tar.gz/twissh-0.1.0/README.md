## Start server

`./run.sh`

## Connect

`ssh localhost -p 6022`


## Known bugs

If shift arrow does not work, be sure to have it properly escaped in you terminal settings


# Math Class H

Manage your crew of mathematicians to the top of the world. Research new theorems, hire the best talent, and even compromise on using less orthodox methods if necessary...

But pay attention to your group mental wellness, otherwise thy could get too stressed and lose their minds.
In that case, legend says they are 'retired' to the pit...

Antoher legend: some mathematicians are righteous among men, or Lamedvavnik. They are so righteous that they can't be fired, even if they are not doing anything. They are also immune to stress.

# Hack'n'Slassh

Alas, adventurer! Welcome to the pit...

You have been sent to the pit to prove your worth and become the village next hero. But beware, the pit is a dangerous place, and you will have to fight your way out.
Some weird and crazy creatures are regularly sent to it, nobody know where they come from, but they keep talking about Langlands and some weird math stuff...



# Gameplay

Start playing math class H. When a mathematician gets crazy, they can sent to the pit. You can log in to hack'n'slash using the ID of the pitted mathematician and try to get out of the pit.

- Login in using nothing: create new math class H game. 
- Login using research group ID: join existing math class H game. 
- Login using pitted mathematician ID: play hack'n'slash.